# chat-Webapp
Key Features:

chat- Webapp is a format that allows customers to communicate directly with brands online, often on their websites and in real time. The web chat window pops up as an overlay of the website page in the browser, allowing the user to type messages directly into a text field, and often attach images and other files as well.


Send targeted welcome messages to connect with engaged site visitors, helping you increase your chances of conversion. 
Chatbots personalize conversations by pulling information about each contact. 
Chat history and contact timeline is saved to your Conversations Inbox so you can refer to each leads journey and history with your business. 